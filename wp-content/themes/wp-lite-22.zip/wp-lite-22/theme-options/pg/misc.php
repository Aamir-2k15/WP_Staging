<fieldset>
    <legend>Misc Settings</legend>

    <?php $field = new FormFields(); ?>

    <?php $field->wp_color('theme_settings[def_primary_color]', 'Primary Color', $options['def_primary_color'],'','','');?>


</fieldset>