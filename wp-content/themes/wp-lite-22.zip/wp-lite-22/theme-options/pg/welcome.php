<fieldset>
    <legend>Basic Info</legend>
    
    <?php $field = new FormFields(); ?>
    
    
    <div class="row pb-3">
        <div class="col-md-6"></div>
        <div class="col-md-6"></div>
    </div>
    

    <hr/>
    <legend>Shortcodes</legend>
        <div class="row pb-3">
        <div class="col-md-4">To Display Website-related:</div>
        <div class="col-md-8">[wpl_search],[map], [address],[phone], [site_email]<br/>
        
        </div>
    </div>
    <div class="row pb-3">
        <div class="col-md-4">To Display Social Media:</div>
        <div class="col-md-8">[facebook], [twitter], [linkedin],[instagram],[pinterest],[youtube],[google-plus]</div>
    </div>

    <div class="row pb-3">
        <div class="col-md-4">To Display Post Count:</div>
        <div class="col-md-8">the_post_views()</div>
    </div>

    <hr/>
    <legend>Developer Notes</legend>
    <div class="row pb-3">
        <div class="col-md-12">
            <ol>
                <li>Remove unnecessary files/fodlers: _misc, this section</li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>                
            </ol>
            
        </div>
        <!--<div class="col-md-6"></div>-->
    </div>
 
    
</fieldset>

